var searchData=
[
  ['prev_0',['prev',['../structNode.html#aea9fefc3628c3ce98b967e8addf06e88',1,'Node']]],
  ['price_1',['price',['../structProducts.html#aa89e8c2471983c3cdaf455887264b07e',1,'Products']]],
  ['product_2',['product',['../structStackNode.html#a892f36972826a916f53a2d3ebe1c7071',1,'StackNode']]],
  ['products_3',['products',['../structNode.html#a5cc329248e3246e3f1de768a366359f9',1,'Node']]]
];
