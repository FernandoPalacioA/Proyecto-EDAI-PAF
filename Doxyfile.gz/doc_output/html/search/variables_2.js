var searchData=
[
  ['id_0',['id',['../structProducts.html#a7f417fdd9927cdb508b075da4b271fa6',1,'Products']]]
];
