var searchData=
[
  ['first_0',['first',['../structStore.html#ab53f17726eade7c72497f77ef933e262',1,'Store']]]
];
