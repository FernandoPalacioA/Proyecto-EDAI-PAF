var searchData=
[
  ['name_0',['name',['../structProducts.html#ae337903e1751e2f76bda8c479568ef8d',1,'Products']]],
  ['next_1',['next',['../structNode.html#af67b110ca1a258b793bf69d306929b22',1,'Node::next'],['../structStackNode.html#ae85b139f0e305c1fe035618882543545',1,'StackNode::next']]],
  ['node_2',['Node',['../structNode.html',1,'']]]
];
