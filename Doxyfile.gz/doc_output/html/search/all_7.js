var searchData=
[
  ['tag_0',['tag',['../structProducts.html#a7c28e1e44f4422a6315271fef83768de',1,'Products']]],
  ['top_1',['top',['../structStack.html#a6d7a736e6dd263d205f4bf7905de651b',1,'Stack']]]
];
