var searchData=
[
  ['codebar_0',['codebar',['../structProducts.html#a026fc4afbc46beed3e5dce1a3aa18ba8',1,'Products']]],
  ['cursor_1',['cursor',['../structStore.html#aff03cf60943e87ab0c364cd8ed8f44fd',1,'Store']]]
];
