var searchData=
[
  ['stock_0',['stock',['../structProducts.html#ac27ff3f1b7d7bf5947a08f0fd5363b98',1,'Products']]],
  ['store_5fname_1',['store_name',['../structStore.html#a7e8fa313411c921c83979165215c92f3',1,'Store']]]
];
